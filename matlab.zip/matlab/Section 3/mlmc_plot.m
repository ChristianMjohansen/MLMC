%
% utility to generate MLMC plots based on input text file mlmc_plot(filename,nvert)
%

function mlmc_plot(filename,nvert,varargin)

close all;

if nargin==2
    error_bars = 0;
elseif nargin==3
    if varargin{1}=='error_bars'
        error_bars = 1;
    else
        error('invalid mlmc_plot option')
    end
else
    nargin
    error('invalid number of mlmc_plot arguments')
end

%
% read in data
%

fid = fopen(['results/' filename '.txt'],'r');

line = '    ';
while (length(line)<20) | (strcmp(line(1:4),'*** ')==0)
    line = [ fgetl(fid) '    ' ];
end
file_version = sscanf(line(23:30),'%f');
if isempty(file_version)
    file_version = 0.8;
end

if (file_version<0.9)
    N = 0;
    if (error_bars)
        error('cannot plot error bars -- no value of N in file');
    end
else
    while (length(line)<20) | (strcmp(line(1:9),'*** using')==0)
        line = [ fgetl(fid) '    ' ];
    end
    N = sscanf(line(14:20),'%d');
end

line = '    ';
while (length(line)<20) | (strcmp(line(1),'-')==0)
    line = [ fgetl(fid) '    ' ];
end

line = fgetl(fid);
l    = 1;
while (length(line)>10)
    data = sscanf(line,'%f');
    del1(l) = data(2);
    del2(l) = data(3);
    var1(l) = data(4);
    var2(l) = data(5);
    kur1(l) = data(6);
    chk1(l) = data(7);
    cost(l) = data(8);
    
    line = fgetl(fid);
    l    = l+1;
end

vvr1 = var1.^2 .* (kur1-1);

L = l-2;

line = '    ';
while (length(line)<20) | (strcmp(line(1),'-')==0)
    line = [ fgetl(fid) '    ' ];
end

line = fgetl(fid);
l    = 1;

while (length(line)>10)
    data = sscanf(line,'%f');
    Eps(l)       = data(1);
    mlmc_cost(l) = data(3);
    std_cost(l)  = data(4);
    len          = length(data)-5;
    ls(1:len,l)  = 1:len;
    Nls(1:len,l) = data(6:end);
    
    line = fgetl(fid);
    l    = l+1;
end

%
% plot figures
%
L1 = 1:L;

set(0,'DefaultAxesColorOrder',[0 0 1; 0 0 1; 1 0 0]);
set(0,'DefaultAxesLineStyleOrder','-*|:*|--o|--x|--d|--s')
%set(0,'DefaultAxesLineStyleOrder','-*|--*')

if nvert == 1
    figure( 'Position',  [600, 600, 600, 300]);
    subplot(nvert,2,1)
    plot(0:L,log2(var2),'-+',1:L,log2(var1(2:end)),'--*',L1,log2(2.^(-L1))+1,'--o')
    xlabel('level $\ell$','Interpreter','latex');
    ylabel('$\log_2$ variance','Interpreter','latex');
    
    current = axis; axis([ 0 L current(3:4) ]);
    legend({'$P_\ell$','$P_\ell\!-\! P_{\ell-1}$','$2^{-\ell}$'}, ...
        'Interpreter','latex','Location','SouthWest')
    grid on
    hold on;
    
    if error_bars
        plot([1:L; 1:L],[log2(max(abs(var1(2:end))-3*sqrt(vvr1(2:end)/N),1e-10)); ...
            log2(    abs(var1(2:end))+3*sqrt(vvr1(2:end)/N))],'-r.')
    end
    
    %     subplot(nvert,3,2)
    %     plot(0:L,log2(abs(del2)),'-+',1:L,log2(abs(del1(2:end))),'--*',L1,log2(2.^(-L1))-7,'--o')
    %     xlabel('level $\ell$','Interpreter','latex');
    %     ylabel('$\log_2 |\mbox{mean}|$','Interpreter','latex');
    %     current = axis; axis([ 0 L current(3:4) ]);
    %     legend({'$P_\ell$','$P_\ell\!-\! P_{\ell-1}$','$2^{-\ell}$'}, ...
    %         'Interpreter','latex','Location','SouthWest')
    %     grid on
    %     hold on;
    
    %plot([0:L; 0:L],[log2(max(abs(del2)-3*sqrt(var2/N),1e-10)); ...
    %                 log2(    abs(del2)+3*sqrt(var2/N))],'-r.')
    if error_bars
        plot([1:L; 1:L],[log2(max(abs(del1(2:end))-3*sqrt(var1(2:end)/N),1e-10)); ...
            log2(    abs(del1(2:end))+3*sqrt(var1(2:end)/N))],'-r.')
    end
    set(0,'DefaultAxesColorOrder',[0 0 1; 1 0 0]);
    
    subplot(nvert,2,2)
    semilogy(1:L,kur1(2:end),'--*')
    xlabel('level $\ell$','Interpreter','latex');
    ylabel('kurtosis');
    current = axis; axis([ 0 L current(3:4) ]);
    grid on
    
    set(0,'DefaultAxesLineStyleOrder','-*|:*')
    %set(0,'DefaultAxesLineStyleOrder','-*|--*')
    
end
if nvert == 2
    pos=get(gcf,'pos'); pos(3:4)=pos(3:4).*[1.1 0.8*nvert]; set(gcf,'pos',pos);
    subplot(nvert,2,1)
    plot(0:L,log2(var2),'-+',1:L,log2(var1(2:end)),'--*',L1,log2(2.^(-3*L1/2) )-11,'--o')
    xlabel('level $\ell$','Interpreter','latex');
    ylabel('$\log_2$ variance','Interpreter','latex');
    
    current = axis; axis([ 0 L current(3:4) ]);
    legend({'$P_\ell$','$P_\ell\!-\! P_{\ell-1}$','$2^{-3\ell/2}$'}, ...
        'Interpreter','latex','Location','SouthWest')
    grid on
    hold on;
    
    if error_bars
        plot([1:L; 1:L],[log2(max(abs(var1(2:end))-3*sqrt(vvr1(2:end)/N),1e-10)); ...
            log2(    abs(var1(2:end))+3*sqrt(vvr1(2:end)/N))],'-r.')
    end
    
    subplot(nvert,2,2)
    plot(1:L,kur1(2:end),'--*')
    xlabel('level $\ell$','Interpreter','latex');
    ylabel('kurtosis');
    current = axis; axis([ 0 L current(3:4) ]);
    grid on
    
    %set(0,'DefaultAxesLineStyleOrder','-*|:*')
    set(0,'DefaultAxesLineStyleOrder','-*|--*')
    set(0,'DefaultAxesColorOrder',[0 0 0; 0 0 1; 1 0 0; 0.5 .5 .5 ]);
    
    subplot(nvert,2,3)
    semilogy(ls, Nls)
    xlabel('level $\ell$','Interpreter','latex');
    ylabel('$M_\ell$','Interpreter','latex');
    current = axis; axis([ 1 size(Nls,1) current(3:4) ]);
    for i=1:length(Eps)
        labels{i} = ['\epsilon = ' num2str(Eps(i))];
    end
    legend(labels,'Location','NorthEast')
    grid on
    hold on;
    
    set(0,'DefaultAxesColorOrder',[0 0 1; 1 0 0]);
    
    subplot(nvert,2,4)
    loglog(Eps,Eps.^2.*std_cost(:)', Eps,Eps.^2.*mlmc_cost(:)')
    xlabel('RMSE $\varepsilon$','Interpreter','latex');
    ylabel('$\varepsilon^2$ Cost','Interpreter','latex');
    current = axis; axis([ Eps(1) Eps(end) current(3:4) ]);
    legend('Std MC','MLMC')
    grid on
      
end


end


